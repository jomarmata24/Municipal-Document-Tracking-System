To intstall the MDTS System you need to click the setup file and the add the shortcut
in your Desktop